/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  Terminal, 
  RefreshCw, 
  Copy, 
  Check, 
  Share2, 
  Code2, 
  Smile, 
  Volume2, 
  VolumeX, 
  ArrowLeft,
  Heart,
  MessageSquareQuote,
  Coffee,
  Bug,
  Laptop
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PROGRAMMING_JOKES, Joke } from './data/jokes';
import { getRandomGreeting } from './data/greetings';

export default function App() {
  const [userName, setUserName] = useState('');
  const [submittedName, setSubmittedName] = useState('');
  const [currentJoke, setCurrentJoke] = useState<Joke | null>(null);
  const [currentGreeting, setCurrentGreeting] = useState<{ greeting: string; badge: string; tone: string } | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [reactions, setReactions] = useState<{ [key: string]: number }>({
    '😂': 12,
    '💻': 8,
    '☕': 19,
    '🐛': 5
  });
  const [userReacted, setUserReacted] = useState<{ [key: string]: boolean }>({});
  const resultRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Play subtle sound on success
  const playChime = () => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      const now = ctx.currentTime;
      // Note 1
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(523.25, now); // C5
      gain1.gain.setValueAtTime(0.08, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.15);

      // Note 2
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(659.25, now + 0.1); // E5
      gain2.gain.setValueAtTime(0.08, now + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.1);
      osc2.stop(now + 0.3);
    } catch {
      // Audio might be blocked until user interaction
    }
  };

  // Trigger celebration confetti
  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10B981', '#6366F1', '#F59E0B', '#EC4899', '#3B82F6']
      });
    } catch {
      // Confetti fallback
    }
  };

  // Generate welcome message and joke
  const handleGenerate = (e?: React.FormEvent, directName?: string) => {
    if (e) e.preventDefault();
    const nameToUse = directName !== undefined ? directName : userName;
    const trimmed = nameToUse.trim();

    if (!trimmed) {
      inputRef.current?.focus();
      return;
    }

    setSubmittedName(trimmed);
    
    // Pick a joke (filtered if a category is selected and not 'الكل', or all jokes)
    const pool = selectedCategory === 'الكل' 
      ? PROGRAMMING_JOKES 
      : PROGRAMMING_JOKES.filter(j => j.category === selectedCategory);
    
    // Pick different joke than current if possible
    let newJoke: Joke;
    if (pool.length > 1 && currentJoke) {
      const otherJokes = pool.filter(j => j.id !== currentJoke.id);
      newJoke = otherJokes[Math.floor(Math.random() * otherJokes.length)];
    } else {
      newJoke = pool[Math.floor(Math.random() * pool.length)];
    }

    const greeting = getRandomGreeting(trimmed);

    setCurrentJoke(newJoke);
    setCurrentGreeting(greeting);
    playChime();
    triggerConfetti();

    // Scroll smoothly to result
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 150);
  };

  // Next joke with same name
  const handleNextJoke = () => {
    if (!submittedName) return;
    handleGenerate(undefined, submittedName);
  };

  // Copy full greeting & joke
  const handleCopy = async () => {
    if (!currentGreeting || !currentJoke) return;
    const textToCopy = `${currentGreeting.greeting}

😂 نكتة اليوم:
${currentJoke.setup}
${currentJoke.punchline}
${currentJoke.codeSnippet ? `\nكود النكتة:\n${currentJoke.codeSnippet}` : ''}

#نكت_برمجية #مبرمج`;

    try {
      await navigator.clipboard.writeText(textToCopy);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  // Share
  const handleShare = async () => {
    if (!currentGreeting || !currentJoke) return;
    const text = `${currentGreeting.greeting}\n\nنكتة برمجية:\n${currentJoke.setup}\n${currentJoke.punchline}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'نكتة برمجية مضحكة',
          text: text,
        });
      } catch {
        // User cancelled share
      }
    } else {
      handleCopy();
    }
  };

  // Handle reaction clicks
  const handleReaction = (emoji: string) => {
    setReactions(prev => ({
      ...prev,
      [emoji]: (prev[emoji] || 0) + (userReacted[emoji] ? -1 : 1)
    }));
    setUserReacted(prev => ({
      ...prev,
      [emoji]: !prev[emoji]
    }));
  };

  const sampleNames = ['أحمد', 'سارة', 'عمر', 'فاطمة', 'طارق', 'ريم'];
  const categories = ['الكل', 'حياة المبرمج', 'كلاسيكيات البرمجة', 'تصميم الواجهات', 'قواعد البيانات', 'أخطاء الصياغة'];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Cairo',sans-serif] selection:bg-emerald-500/30 selection:text-emerald-300 relative overflow-x-hidden">
      
      {/* Background ambient lighting */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-emerald-600/15 rounded-full blur-3xl"></div>
        <div className="absolute top-1/3 -left-40 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl"></div>
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b0a_1px,transparent_1px),linear-gradient(to_bottom,#1e293b0a_1px,transparent_1px)] bg-[size:32px_32px]"></div>
      </div>

      {/* Top Navbar */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 px-4 py-3.5 sm:px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20 font-bold">
              <Terminal className="w-5 h-5 text-slate-950 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg text-white leading-tight">مُبرمج كافيه</h1>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                  v2.0
                </span>
              </div>
              <p className="text-xs text-slate-400">ترحيب مخصص وأطرف النكات البرمجية</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'كتم المؤثرات الصوتية' : 'تفعيل المؤثرات الصوتية'}
              className="p-2 rounded-lg bg-slate-800/70 border border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-800 transition"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 px-2.5 py-1 rounded-lg bg-slate-800/40 border border-slate-800">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>+{PROGRAMMING_JOKES.length} نكتة حصرية</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 max-w-3xl w-full mx-auto px-4 py-8 sm:py-12 flex flex-col gap-8">
        
        {/* Hero Section & Form */}
        <div className="text-center space-y-3">
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-2"
          >
            <Smile className="w-3.5 h-3.5" />
            <span>ابتسم.. أنت في استراحة المبرمجين</span>
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight"
          >
            اكتب اسمك واستقبل <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">نكتتك البرمجية!</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-sm sm:text-base text-slate-300 max-w-lg mx-auto"
          >
            أدخل اسمك أدناه، وسنقوم بالترحيب بك باسمك الخاص مع نكتة طريفة من مواقف البرمجة والأخطاء والكود.
          </motion.p>
        </div>

        {/* Input Card */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.25 }}
          className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-5 sm:p-7 shadow-xl shadow-black/30 backdrop-blur-sm"
        >
          <form onSubmit={handleGenerate} className="space-y-5">
            <div className="space-y-2">
              <label htmlFor="user-name-input" className="block text-sm font-semibold text-slate-200">
                الاسم الكريم أو لقبك البرمجي:
              </label>
              
              <div className="relative flex items-center">
                <input
                  id="user-name-input"
                  ref={inputRef}
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="مثال: أحمد، سارة، مبرمج الليل..."
                  className="w-full bg-slate-950 border border-slate-700/80 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 rounded-xl py-3.5 px-4 text-base text-white placeholder-slate-500 transition outline-none"
                  autoComplete="name"
                  maxLength={40}
                />
                {userName && (
                  <button
                    type="button"
                    onClick={() => { setUserName(''); inputRef.current?.focus(); }}
                    className="absolute left-3 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/80 px-2 py-1 rounded-md"
                  >
                    مسح
                  </button>
                )}
              </div>
            </div>

            {/* Quick Name Suggestions */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-xs text-slate-400 ml-1">أو جرّب اسماً سريعاً:</span>
              {sampleNames.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => {
                    setUserName(name);
                    handleGenerate(undefined, name);
                  }}
                  className="text-xs px-2.5 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-emerald-300 border border-slate-700/50 transition cursor-pointer"
                >
                  {name}
                </button>
              ))}
            </div>

            {/* Category Filter Pills */}
            <div className="space-y-2 pt-2 border-t border-slate-800/60">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>نوع النكتة المفضلة (اختياري):</span>
                <span className="text-emerald-400 font-mono">{selectedCategory}</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition ${
                      selectedCategory === cat
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-medium'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!userName.trim()}
              className={`w-full py-3.5 px-6 rounded-xl font-bold text-base flex items-center justify-center gap-2.5 transition-all shadow-lg ${
                userName.trim()
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 shadow-emerald-500/20 hover:shadow-emerald-500/30 scale-100 hover:scale-[1.01] active:scale-[0.99] cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed shadow-none'
              }`}
            >
              <Sparkles className="w-5 h-5 text-slate-950" />
              <span>اطبع الترحيب والنكتة البرمجية</span>
              <span className="text-xs bg-slate-950/20 text-slate-900 px-2 py-0.5 rounded font-mono hidden sm:inline">Enter ↵</span>
            </button>
          </form>
        </motion.div>

        {/* Result Display Area */}
        <div ref={resultRef}>
          <AnimatePresence mode="wait">
            {currentJoke && currentGreeting && (
              <motion.div
                key={`${currentJoke.id}-${submittedName}`}
                initial={{ opacity: 0, y: 25, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.97 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-700/80 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden"
              >
                {/* Decorative glow */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

                {/* Personalized Welcome Banner */}
                <div className="mb-6 pb-6 border-b border-slate-800">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                      {currentGreeting.badge}
                    </span>
                    <span className="text-xs text-slate-400">
                      طلب بواسطة: <strong className="text-slate-200">{submittedName}</strong>
                    </span>
                  </div>
                  
                  <div className="flex items-start gap-3 mt-3">
                    <div className="p-2.5 rounded-xl bg-slate-800/90 text-emerald-400 shrink-0">
                      <MessageSquareQuote className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-bold text-white leading-snug">
                        {currentGreeting.greeting}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        إليك هذه النكتة المختارة لك خصيصاً لتنعش يومك البرمجي:
                      </p>
                    </div>
                  </div>
                </div>

                {/* Joke Card */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-medium border border-slate-700/60">
                      {currentJoke.categoryBadge}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Smile className="w-3.5 h-3.5 text-amber-400" />
                      <span>نكتة #{currentJoke.id}</span>
                    </div>
                  </div>

                  {/* Joke Setup */}
                  <div className="p-4 sm:p-5 rounded-xl bg-slate-950/70 border border-slate-800/90">
                    <p className="text-base sm:text-lg text-slate-200 font-medium leading-relaxed">
                      {currentJoke.setup}
                    </p>
                  </div>

                  {/* Joke Punchline */}
                  <div className="p-4 sm:p-5 rounded-xl bg-gradient-to-r from-emerald-950/30 via-slate-900 to-teal-950/30 border border-emerald-500/30 shadow-inner">
                    <div className="text-xs font-bold text-emerald-400 mb-1 flex items-center gap-1">
                      <span>😂 الجواب / النهاية:</span>
                    </div>
                    <p className="text-lg sm:text-xl font-extrabold text-emerald-300 leading-relaxed">
                      {currentJoke.punchline}
                    </p>
                  </div>

                  {/* Optional Code Snippet */}
                  {currentJoke.codeSnippet && (
                    <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#0d1117] text-left" dir="ltr">
                      <div className="bg-slate-900/90 px-3 py-1.5 flex items-center justify-between border-b border-slate-800 text-xs text-slate-400 font-mono">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-red-500/80"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
                          <span className="ml-2 text-slate-400">joke.ts</span>
                        </div>
                        <Code2 className="w-3.5 h-3.5 text-slate-500" />
                      </div>
                      <pre className="p-3.5 text-xs sm:text-sm font-mono text-emerald-400/90 overflow-x-auto whitespace-pre">
                        <code>{currentJoke.codeSnippet}</code>
                      </pre>
                    </div>
                  )}

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {currentJoke.tags.map((tag) => (
                      <span key={tag} className="text-[11px] text-slate-400 bg-slate-800/50 px-2 py-0.5 rounded">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  {/* Reactions */}
                  <div className="flex items-center gap-2 pt-3 border-t border-slate-800/70">
                    <span className="text-xs text-slate-400 ml-1">تفاعل مع النكتة:</span>
                    {Object.entries(reactions).map(([emoji, count]) => {
                      const active = userReacted[emoji];
                      return (
                        <button
                          key={emoji}
                          onClick={() => handleReaction(emoji)}
                          className={`text-xs flex items-center gap-1 px-2.5 py-1 rounded-full border transition cursor-pointer ${
                            active 
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                              : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <span>{emoji}</span>
                          <span className="font-mono text-[11px]">{count}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-wrap items-center gap-2.5 pt-4">
                    <button
                      onClick={handleNextJoke}
                      className="flex-1 min-w-[140px] py-2.5 px-4 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>نكتة أخرى يا {submittedName}</span>
                    </button>

                    <button
                      onClick={handleCopy}
                      className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700/90 border border-slate-700 text-slate-200 font-medium text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
                      title="نسخ الترحيب والنكتة"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-400" />
                          <span className="text-emerald-400">تم النسخ!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 text-slate-300" />
                          <span>نسخ</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleShare}
                      className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700/90 border border-slate-700 text-slate-200 font-medium text-sm flex items-center justify-center gap-1.5 transition cursor-pointer"
                      title="مشاركة النكتة"
                    >
                      <Share2 className="w-4 h-4 text-slate-300" />
                      <span>مشاركة</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Features / Info Section */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-4">
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
              <Coffee className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-200">استراحة من الكود</h4>
              <p className="text-[12px] text-slate-400 mt-0.5">جرعة مرح تخفف ضغط المشاريع ومشاكل الـ Debugging.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 shrink-0">
              <Laptop className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-200">نكات مخصصة بالاسم</h4>
              <p className="text-[12px] text-slate-400 mt-0.5">ترحيب خاص ولطيف مصمم بذكاء لكل اسم مبرمج.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
              <Bug className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-200">مواقف واقعية</h4>
              <p className="text-[12px] text-slate-400 mt-0.5">نكات يفهمها كل من كتب سطراً برمجياً أو حلل داتابيز.</p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800/80 bg-slate-950 py-5 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <span>صُنع بحب للمبرمجين العرب</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 inline fill-rose-500" />
          </div>
          <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
            <span>&lt;code&gt;keep_coding & keep_smiling()&lt;/code&gt;</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
