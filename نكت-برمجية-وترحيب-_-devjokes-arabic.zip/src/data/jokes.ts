export interface Joke {
  id: number;
  category: string;
  categoryBadge: string;
  setup: string;
  punchline: string;
  codeSnippet?: string;
  tags: string[];
}

export const PROGRAMMING_JOKES: Joke[] = [
  {
    id: 1,
    category: "حياة المبرمج",
    categoryBadge: "☕ روتين المبرمج",
    setup: "سألوا مبرمج: ليش بتشرب قهوة كتير طول اليوم؟",
    punchline: "قالهم: لأني لو طفيت بصير عندي NullPointerException في الذاكرة!",
    codeSnippet: "if (coffeeCups === 0) { throw new BrainCrashException(); }",
    tags: ["قهوة", "أخطاء", "ذاكرة"]
  },
  {
    id: 2,
    category: "كلاسيكيات البرمجة",
    categoryBadge: "🛒 منطق شرطي",
    setup: "مبرمج راح السوبرماركت، زوجته قالت له: 'اشتري كرتونة حليب، وإذا لقيت بيض جيب 10'.",
    punchline: "رجع البيت ومعه 10 كراتين حليب! صرخت فيه: ليش؟! قال: 'لأني لقيت بيض!'",
    codeSnippet: "let milk = 1;\nif (eggsExist) {\n  milk = 10;\n}",
    tags: ["شروط", "if_statement", "سوء_تفاهم"]
  },
  {
    id: 3,
    category: "تصميم الواجهات",
    categoryBadge: "🎨 فرونت إند",
    setup: "كيف تعذّب مبرمج واجهات ويب (Frontend) بدون ما تلمسه؟",
    punchline: "اطلب منه يوسّط عنصر <div> عمودياً وأفقياً بـ CSS قديم بدون Flexbox أو Grid!",
    codeSnippet: "div {\n  /* كيف كانت الحياة قبل Flexbox؟ كابوس! */\n  margin: auto;\n  position: absolute; \n}",
    tags: ["CSS", "توسيط_div", "فرونت_إند"]
  },
  {
    id: 4,
    category: "أخطاء برمجية",
    categoryBadge: "🩺 طب رقمي",
    setup: "طبيب لمبرمج بعد الفحص: 'صحتك ممتازة وجسمك ما فيه أي عيب أو مشكلة'.",
    punchline: "المبرمج رد بقلق: 'غريبة جداً! مع إن كل الأعراض كانت شغالة عندي تمام في البيت (Local)!'",
    codeSnippet: "// It works on my machine!\nconst health = testLocally();",
    tags: ["Local", "بيئة_العمل", "طب"]
  },
  {
    id: 5,
    category: "حياة المبرمج",
    categoryBadge: "🌙 الوضع الليلي",
    setup: "ليش المبرمج بيكره يخرج في شمس الصيف والنهار؟",
    punchline: "لأنه متعود يعيش في الـ Dark Mode، والشمس ما فيها زر تبديل للـ Dark Theme!",
    codeSnippet: "document.body.classList.contains('sun') ? runAway() : chill();",
    tags: ["دارك_مود", "شمس", "روتين"]
  },
  {
    id: 6,
    category: "لغات البرمجة",
    categoryBadge: "⚡ لغة C",
    setup: "ليش لغة C مش خايفة من أي لغة برمجة تانية في العالم؟",
    punchline: "لأنها لغة ما عندها Class! (ما في كلاسات OOP)!",
    codeSnippet: "#include <stdio.h>\nint main() { printf(\"No class, no fear!\"); }",
    tags: ["C", "OOP", "كلاسات"]
  },
  {
    id: 7,
    category: "قواعد البيانات",
    categoryBadge: "🗄️ SQL و داتابيز",
    setup: "مبرمج دخل مطعم وطلب طاولة، سألوه عن اسمه فقال: 'Robert\'); DROP TABLE Students;--'",
    punchline: "المطعم كله انحذف من السجل المدني وانهارت قائمة الطلبات فوراً! (Little Bobby Tables الشهيرة)",
    codeSnippet: "SELECT * FROM Users WHERE name = 'Robert'); DROP TABLE Users;--';",
    tags: ["SQL_Injection", "أمان", "داتابيز"]
  },
  {
    id: 8,
    category: "إدارة المشاريع",
    categoryBadge: "🐞 بجز وفيتشرز",
    setup: "مبرمج مبتدئ قال للمدير: 'عندي Bug مستحيل ينحل في الكود، شو نسوي؟'",
    punchline: "المدير: 'بسيطة! بنكتب في وصف التحديث إنه ميزة جديدة (Undocumented Feature) ونرفع السعر!'",
    codeSnippet: "// It's not a bug, it's an undocumented feature 🚀",
    tags: ["Bug", "Feature", "إدارة"]
  },
  {
    id: 9,
    category: "جافاسكربت",
    categoryBadge: "💛 عجائب JS",
    setup: "سألت جافاسكربت: 'كم ناتج [] + [] ؟' قالت: '' (نص فارغ). طب '[] + {}'؟ قالت '[object Object]'. طب '{} + []'؟",
    punchline: "قالت: 0! سألتها ليش؟ قالت: 'أنا جافاسكربت وأفعل ما يحلو لي، وإذا مش عاجبك استخدم TypeScript!'",
    codeSnippet: "console.log([] + []); // \"\"\nconsole.log(typeof NaN); // \"number\" 🤯",
    tags: ["JavaScript", "TypeScript", "غرائب"]
  },
  {
    id: 10,
    category: "حياة المبرمج",
    categoryBadge: "🌿 الطبيعة والبرمجة",
    setup: "ليش المبرمجين بيكرهوا الرحلات والتخييم في الطبيعة والغابات؟",
    punchline: "لأن الأشجار هناك ما فيها فروع Git (Branches)، وكلها حشرات حقيقية (Bugs) بدون ديباجر!",
    codeSnippet: "git checkout -b real-nature\n// Fatal: Too many actual bugs detected!",
    tags: ["Git", "طبيعة", "Bugs"]
  },
  {
    id: 11,
    category: "نظام العد الثنائي",
    categoryBadge: "0️⃣1️⃣ باينري",
    setup: "يوجد في هذا العالم 10 أنواع فقط من البشر..",
    punchline: "النوع الأول: اللي بيفهموا النظام الثنائي (Binary)، والنوع التاني: اللي ما بيفهموه!",
    codeSnippet: "0b10 === 2; // الرياضيات في عيون المبرمجين",
    tags: ["Binary", "رياضيات", "حاسوب"]
  },
  {
    id: 12,
    category: "نظارات وتحديق",
    categoryBadge: "👓 لغات مايكروسوفت",
    setup: "ليش أغلب مبرمجي الدوت نت بيلبسوا نظارات طبية؟",
    punchline: "عشان يشوفوا لغة C# بوضوح (C-Sharp) وما تغبّش عليهم الرؤية!",
    codeSnippet: "using System;\nConsole.WriteLine(\"Looking sharp! 🕶️\");",
    tags: ["CSharp", "نظارات", "دوت_نت"]
  },
  {
    id: 13,
    category: "أخطاء الصياغة",
    categoryBadge: "🔍 الفاصلة المنقوطة",
    setup: "أقصر قصة رعب عاشها مبرمج في تاريخ البشرية:",
    punchline: "قضى 7 ساعات متواصلة يبحث عن سبب انهيار المشروع.. وفي النهاية كانت فاصلة منقوطة (;) روسية متخفية!",
    codeSnippet: "const greeting = 'Hello World'; // 😱 اليونانية مش الإنجليزية!",
    tags: ["SyntaxError", "فاصلة_منقوطة", "رعب"]
  },
  {
    id: 14,
    category: "الشبكات والإنترنت",
    categoryBadge: "🌐 بروتوكولات",
    setup: "سألوا مبرمج: كيف كان الطقس برا اليوم لما نزلت؟",
    punchline: "قالهم: 404 Weather Not Found! كانت الشبكة واقعة وما شفت غير شاشة التحميل!",
    codeSnippet: "HTTP/1.1 404 Weather Not Found\nContent-Type: text/sandstorm",
    tags: ["404", "HTTP", "شبكات"]
  },
  {
    id: 15,
    category: "الذكاء الاصطناعي",
    categoryBadge: "🤖 شات جي بي تي",
    setup: "مبرمج بيشتكي: 'خايف الذكاء الاصطناعي ياخد وظيفتي في كتابة الكود'.",
    punchline: "صاحبه رد عليه: 'لا تقلق، الذكاء الاصطناعي محتاج العميل يشرح له المتطلبات بوضوح، وطالما العميل مش عارف شو بدّه وظيفتك بأمان طول العمر!'",
    codeSnippet: "prompt: 'اعمل لي فيسبوك تاني بس أحسن وبدون مصاري'",
    tags: ["AI", "عملاء", "متطلبات"]
  },
  {
    id: 16,
    category: "علاقات وزواج",
    categoryBadge: "💍 خطوبة برمجية",
    setup: "مبرمج قرر يتزوج، أهله سألوه شو مواصفات شريكة أحلامك؟",
    punchline: "قالهم: تكون Responsive على كل الشاشات، وعندها Low Latency في الرد، وما بتسرب ذاكرة (No Memory Leak)!",
    codeSnippet: "const spouse = new Partner({ responsive: true, leaks: false });",
    tags: ["زواج", "مواصفات", "ذاكرة"]
  },
  {
    id: 17,
    category: "النسخ واللصق",
    categoryBadge: "📋 ستاك أوفر فلو",
    setup: "ما هو التعريف الدقيق للمبرمج في القرن الـ 21؟",
    punchline: "هو جهاز حيوي يحوّل القهوة والشاي إلى عمليات Ctrl+C و Ctrl+V من Stack Overflow!",
    codeSnippet: "document.addEventListener('keydown', (e) => {\n  if (e.ctrlKey && e.key === 'v') shipToProduction();\n});",
    tags: ["StackOverflow", "نسخ_ولصق", "قهوة"]
  },
  {
    id: 18,
    category: "حوادث وسيارات",
    categoryBadge: "🚗 كول باك",
    setup: "مبرمج صدم شجرة بسيارته.. جاء ضابط المرور وسأله: ليش ما دعست فرامل؟",
    punchline: "المبرمج وهو يرتجف: 'والله دعست يا حضرة الضابط، بس الـ Callback كان غير متزامن (Async) وما رجع في الوقت المناسب!'",
    codeSnippet: "async function brake() { await wait(5000); applyBrakes(); }",
    tags: ["Async", "Callback", "فرامل"]
  },
  {
    id: 19,
    category: "عائلة وأطفال",
    categoryBadge: "👨‍👩‍👧 جيت وفورك",
    setup: "سألوا مهندس برمجيات مخضرم: ما شاء الله، كم ولد عندك؟",
    punchline: "قالهم: اتنين.. واحد Main والتاني Fork، وشغالين نعمل Merge للثالث قريب إن شاء الله!",
    codeSnippet: "git fork family\ngit checkout -b kid-3",
    tags: ["Git", "Fork", "Merge"]
  },
  {
    id: 20,
    category: "سيرفرات وإنتاج",
    categoryBadge: "🚨 برودكشن",
    setup: "متى يحس المبرمج بأعلى درجات الأدرينالين والنشاط القلبي؟",
    punchline: "يوم الجمعة الساعة 4:59 عصراً وهو بيضغط زر 'Deploy to Production' ويقفل اللابتوب ويهرب!",
    codeSnippet: "git push origin main --force # يوم الجمعة بعد العصر 💥",
    tags: ["Deploy", "Production", "يوم_الجمعة"]
  },
  {
    id: 21,
    category: "قواعد البيانات",
    categoryBadge: "🔑 علاقات المفاتيح",
    setup: "ليش مبرمج الداتابيز كان حزين ومكتئب في الفالنتاين؟",
    punchline: "لأنه اكتشف إنه عايش في علاقة One-to-Many بينما هو عم يبحث عن One-to-One!",
    codeSnippet: "FOREIGN KEY (heart_id) REFERENCES EmptyLife(id);",
    tags: ["SQL", "Relationships", "حب_رقمي"]
  },
  {
    id: 22,
    category: "أجهزة وأنظمة",
    categoryBadge: "🔒 صلاحيات الروت",
    setup: "المبرمج بيكلم السيرفر بلطف: 'أنا وأنت أصدقاء ودايماً بفيدك، خليني أعدل هذا الملف؟'",
    punchline: "السيرفر ببرود: 'sudo su أو طير من هون.. Access Denied!'",
    codeSnippet: "User is not in the sudoers file. This incident will be reported.",
    tags: ["Linux", "Sudo", "صلاحيات"]
  }
];
