export interface GreetingTemplate {
  template: (name: string) => string;
  badge: string;
  tone: string;
}

export const GREETING_TEMPLATES: GreetingTemplate[] = [
  {
    template: (name: string) => `أهلاً وسهلاً بالمهندس/ة المبدع/ة ${name}! 💻✨ نورت الكود وسطور البرمجة.`,
    badge: "🚀 ترحيب تكنولوجي",
    tone: "متحمس"
  },
  {
    template: (name: string) => `يا هلا بالأسطورة ${name}! تفضل فنجان قهوة كودينغ ☕، جاهز لجرعة ضحك برمجية؟`,
    badge: "☕ روقان ومزاج",
    tone: "ودود"
  },
  {
    template: (name: string) => `حيّاك الله يا ${name}! جعل الله كل أكوادك خالية من البجز (Zero Bugs) وأخطاء السيرفر 🛡️`,
    badge: "🐞 دعاء المبرمجين",
    tone: "دعائي لطيف"
  },
  {
    template: (name: string) => `مرحباً يا بطل الكونسول ${name}! أمر الطباعة print("${name}") تم تنفيذه بنجاح وبسرعة 1ms ⚡`,
    badge: "⚡ سرعة قياسية",
    tone: "تقني"
  },
  {
    template: (name: string) => `أهلاً يا باشمهندس ${name}! رصيدك من الضحك والابتسام تم تحديثه، تفضل نكتتك البرمجية! 😄`,
    badge: "🌟 طاقة إيجابية",
    tone: "مرح"
  },
  {
    template: (name: string) => `يا مرحب بـ ${name}! تم فتح جلسة جديدة بدون أي Memory Leak خصيصاً لأجلك 🎈`,
    badge: "🧠 جلسة نظيفة",
    tone: "فكاهي"
  }
];

export function getRandomGreeting(name: string): { greeting: string; badge: string; tone: string } {
  const cleanName = name.trim();
  const randomIndex = Math.floor(Math.random() * GREETING_TEMPLATES.length);
  const selected = GREETING_TEMPLATES[randomIndex];
  return {
    greeting: selected.template(cleanName),
    badge: selected.badge,
    tone: selected.tone
  };
}
